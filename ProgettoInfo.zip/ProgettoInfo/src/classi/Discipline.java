/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package classi;

/**
 *
 * @author gambonig
 */
public class Discipline {
    private String codice, nome, corso;
    private int cfu;

    public Discipline(String codice, String nome, int cfu, String corso) {
        this.codice = codice;
        this.nome = nome;
        this.corso = corso;
        this.cfu = cfu;
    }
    
    @Override
    public String toString(){
        return codice+";"+nome+";"+cfu+";"+corso;
    }
}

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package classi;

/**
 *
 * @author gambonig
 */
public class Studenti {
    private String matricola, nome, cognome, corso;

    public Studenti(String matricola, String nome, String cognome, String corso) {
        this.matricola = matricola;
        this.nome = nome;
        this.cognome = cognome;
        this.corso = corso;
    }
    
    @Override
    public String toString(){
        return matricola+";"+nome+";"+cognome+";"+corso;
    }
}

package model;

import java.util.ArrayList;
import java.util.List;

/**
 * Author Ghanem Boumalik
 */
public class Docente {
    private String matricola;
    private String nome;
    private String cognome;
    private String disciplina;
    private List<Disciplina> materie;

    public Docente(String matricola, String nome, String cognome, String disciplina) {
        if ("".equals(matricola) || "".equals(nome) || "".equals(cognome) || disciplina == null) {
            throw new IllegalArgumentException("Dati non validi per il docente.");
        }
        this.matricola = matricola;
        this.nome = nome;
        this.cognome = cognome;
        this.disciplina = disciplina;
        this.materie = new ArrayList();
    }

    public String getMatricola() {
        return matricola;
    }

    public String getNome() {
        return nome;
    }

    public String getCognome() {
        return cognome;
    }

    public String getDisciplina() {
        return disciplina;
    }
    
    public Boolean isEliminabile(){
        if("".equals(this.materie)){
            return true;
        }return false;
    }
    @Override
    public String toString(){
        return matricola+";"+nome+";"+cognome+";"+disciplina;
    }
}
package model;

import java.util.ArrayList;
import java.util.List;
/**
 * Classe Corso
 * Author Ghanem Boumalik
 */
public class Corso {
    private String codice;
    private String nome;
    private int durata;
    private List<Appello> appelli;
    private List<Studente> studenti;
    private List<Docente> docenti;

    public Corso(String codice, String nome, int durata) {
        if ("".equals(codice) || "".equals(nome) || durata <= 0) {
            throw new IllegalArgumentException("Dati non validi per il corso.");
        }
        this.codice = codice;
        this.nome = nome;
        this.durata = durata;
        this.appelli = new ArrayList<>();
        this.studenti = new ArrayList();
        this.docenti = new ArrayList();
    }

    public String getCodice() {
        return codice;
    }

    public String getNome() {
        return nome;
    }

    public int getDurata() {
        return durata;
    }
    public List<Appello> getAppelli() {
        return appelli;
    }
    public List<Studente> getStudenti() {
        return studenti;
    }
    public List<Docente> getDocenti() {
        return docenti;
    }

    public Boolean isEliminabile(){
        if("".equals(this.getAppelli())){
            if("".equals(this.getDocenti())){
                if("".equals(this.getStudenti())){
                    return true;
                }
            }
        }
        return false;
    }
    
    @Override
    public String toString(){
        return codice+";"+nome+";"+durata;
    }

    public void setCodice(String nuovoCodice) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    public void setNome(String nuovoNome) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    public void setDurata(int durataNumerica) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }
}
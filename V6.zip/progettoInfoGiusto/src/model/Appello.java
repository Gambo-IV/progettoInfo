package model;

import java.time.LocalDate;
import java.util.ArrayList;
/**
 * Classe Appello
 * Author Ghanem Boumalik
 */
public class Appello {
    private String dataEsame;
    private String id;
    private String codiceDisciplina;
    private ArrayList<Studente> iscritti;

    public Appello(String id, String dataEsame, String codiceDisciplina) {
        if (dataEsame == null || id == null || codiceDisciplina == null) {
            throw new IllegalArgumentException("Dati non validi per l'appello.");
        }
        this.dataEsame = dataEsame;
        this.id = id;
        this.codiceDisciplina = codiceDisciplina;
        this.iscritti = new ArrayList<>();
    }

    public String getDataEsame() {
        return dataEsame;
    }

    public String getID() {
        return id;
    }

    public String getDisciplina() {
        return codiceDisciplina;
    }

    public ArrayList<Studente> getIscritti() {
        return iscritti;
    }

    public void aggiungiStudente(Studente studente) {
        if (studente != null && !iscritti.contains(studente)) {
            iscritti.add(studente);
        }
    }
    
    public Boolean isEliminabile(){
        if("".equals(this.iscritti)){
            return true;
        }return false;
    }
    @Override
    public String toString(){
        return id+";"+dataEsame+";"+codiceDisciplina;
    }
}